package com.example.myapplication

import android.os.Bundle
import android.widget.ImageView
import androidx.activity.ComponentActivity
import com.squareup.picasso.Picasso

class FanActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fan)

        val imageView: ImageView = findViewById(R.id.fanImage)

        val imageUrl = "https://newwavethailand.com/upload-img/%E0%B8%AA%E0%B8%B4%E0%B8%99%E0%B8%84%E0%B9%89%E0%B8%B2_Product_Image_/F-1012_%E0%B9%81%E0%B8%9A%E0%B8%9A%E0%B9%84%E0%B8%A1%E0%B9%88%E0%B8%A2%E0%B8%B7%E0%B8%94/Newwave-Fan-F-1012-Blue.png"

        Picasso.get()
            .load(imageUrl)
            .placeholder(R.drawable.ic_launcher_foreground) // รูประหว่างโหลด
            .error(R.drawable.ic_launcher_foreground)       // รูปกรณี error
            .into(imageView)
    }
}
